<?php echo $__env->make('Frontend.master.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('main-content'); ?>


<?php echo $__env->make('Frontend.master.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(".alert:not(.not_hide)").delay(5000).slideUp(500, function() {
        $(this).alert('close');
    });
</script>



<?php /**PATH C:\Users\Nazmul\Desktop\Apartment-Finding-System\Backend\resources\views/Frontend/master/master.blade.php ENDPATH**/ ?>