

<?php $__env->startSection('main_content'); ?>
    <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="page-header">
                <h3 class="page-title">
                    <a class="btn btn-success btn-rounded" href="<?php echo e(route('seller.apartment')); ?>"><i class="fa fa-plus">
                        </i>&nbsp ADD Apartment</a>

                </h3>
              
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                <table id="order-listing" class="table">
                                    <thead>
                                        <tr>
                                            <th>#ID</th>
                                            <th>Apartment Name</th>
                                            <th>Price</th>
                                            <th>Sell/Rent</th>
                                            <th>City</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $apartment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>

                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->apartment_name); ?></td>
                                                <td><?php echo e($item->price); ?></td>
                                                <td class="text-capitalize">
                                                    <span
                                                        class="badge badge-info"><?php echo e($item->rent_sell == '0' ? 'Rent' : ''); ?></span>
                                                    <span
                                                        class="badge badge-primary"><?php echo e($item->rent_sell == '1' ? 'Sell' : ''); ?></span>
                                                </td>
                                                <td><?php echo e($item->city); ?></td>

                                                <td class="text-capitalize">
                                                    <span
                                                        class="badge badge-danger"><?php echo e($item->status == '0' ? 'deactive' : ''); ?></span>
                                                    <span
                                                        class="badge badge-success"><?php echo e($item->status == '1' ? 'active' : ''); ?></span>
                                                </td>
                                                <td class="text-capitalize">
                                                    <select  class="form-control form-control-sm bg-info text-white" data-id="<?php echo e($item->id); ?>" id="selectStatus">
                                                        <option class="text-white" value="0" <?php echo e($item->status == 0 ? 'selected' : ''); ?>>Deactive</option>                                                                  
                                                        <option value="1" <?php echo e($item->status == 1 ? 'selected' : ''); ?>>Active</option>                                                  
                                
                                                      </select>
                                                </td>




                                                <td>
                                                    <a href="<?php echo e(route('seller.viewApartment',$item->id)); ?>"> <button class="btn btn-outline-primary">View</button></a>

                                                    <a href="<?php echo e(route('seller.apartmentEdit',$item->id)); ?>">
                                                        <button class="btn btn-outline-primary">Edit</button></a>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <td colspan="5" class="text-center">No data Available</td>
                                            </tr>
                                        <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <script>
            //Status update ajax
          $(document).ready(function () {
              $(document).on('change','#selectStatus',function () {
                  let status = $(this).val();
                  let id = $(this).attr('data-id');
                  let selectUpdate = $(this).parent().prev();
          
                  $.ajax({
                      type: 'GET',
                      url: `/Seller/status/${id}`,
                      data: {status: status},
                      success: (data) => {
                        toastr.options = {
                    "timeOut": "2000",
                    "closeButton": true,
                };
                toastr['info']('Status Successfully Updated!!!');
                      
                          if (status == '0'){
                                      $(selectUpdate).html(`
                                      <span class="badge bg-danger text-white">Deactive</span>
                                  `)
                                  }else if (status == '1') {
                                      $(selectUpdate).html(`
                                      <span class="badge bg-success text-white">Active</span>
                                  `)
                                  }
                      },
                      error: (error) => {
                          console.log(error);
                      }
                  })
              });
          });
          </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laravel\New folder\Apartment-Finding-System\Backend\resources\views/seller/apartment/view_apartment.blade.php ENDPATH**/ ?>