

<?php $__env->startSection('main-content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laravel\New folder\Apartment-Finding-System\Backend\resources\views/Frontend/interior_service/residential.blade.php ENDPATH**/ ?>