

<?php $__env->startSection('main_content'); ?>
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="container rounded bg-white mb-3">

                            <div class="row">
                                <form action="<?php echo e(route('seller.updateApartment',$apartment->id)); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-md-12 border-right">



                                        <div class="row ">

                                            <div class="col-md-6 mb-2"><label class="labels text-capitalize">Feature
                                                    Picture</label><br>

                                                <img id="file-id-preview" class="mt-5" width="150px" src="" />
                                                <input id="uploadFile" type="file" onchange="showPreview(event);" name="image"
                                                    class="btn btn-primary btn-sm profile-button  mt-2 text-uppercase" />
                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>



                                            <div class="col-md-6 mb-2"><label class="labels text-capitalize">Multiple
                                                    Picture</label><br>
                                                <img id="multiple_image_preview" class="mt-5" width="150px" src="" />
                                                <input type="file" name="image_file[]"
                                                    class="btn btn-primary btn-sm profile-button  mt-2 text-uppercase"
                                                    multiple />
                                                    <?php $__errorArgs = ['image_file[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>

                                            <div class="col-md-6"><label class="labels text-capitalize">Old Feature
                                                    Picture</label><br>
                                                <img id="" class="mt-1" width="100px"
                                                    src="<?php echo e(url('uploads/apartment_image/' . $apartment->image)); ?>" />
                                            </div>

                                            <div class="col-md-6"><label class="labels text-capitalize">Old Multiple
                                                    Picture</label><br>
                                                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <img class="mt-1" width="100px"
                                                        src="<?php echo e(url('uploads/galleries/' . $data->image_file)); ?>" />

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </div>



                                            <div class="col-md-6 form-group mt-2">
                                                <label class="text-capitalize ">Apartment Name</label>
                                                <input type="text" name="name" class="form-control text-capitalize"
                                                    value="<?php echo e($apartment->apartment_name); ?>"
                                                    placeholder="Enter apartment name">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-md-6 form-group mt-2">
                                                <label class="text-capitalize ">Apartment address</label>
                                                <input type="text" name="address" class="form-control text-capitalize"
                                                    value="<?php echo e($apartment->address); ?>" placeholder="Enter property address">
                                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize ">Apartment size</label>
                                                <input type="text" name="flat_size" class="form-control text-capitalize"
                                                value="<?php echo e($apartment->flat_size); ?>" placeholder="Enter flat size">
                                                <?php $__errorArgs = ['flat_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize">contact</label>
                                                <input type="number" name="contact" class="form-control text-capitalize"
                                                value="<?php echo e($apartment->contact); ?>" placeholder="Enter phone number">
                                                <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize">City</label>
                                                <select name="city" class="form-control form-control-lg"
                                                    id="exampleFormControlSelect2">
                                                    <option selected disabled>select</option>
                                                    <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e($item->name == $item->name? 'selected': ''); ?> value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize">Rent/price</label>
                                                <input type="text" name="price" class="form-control text-capitalize"
                                                value="<?php echo e($apartment->price); ?>" placeholder="Enter rent amount">
                                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize">Bed</label>
                                                <input type="text" name="bed" class="form-control text-capitalize"
                                                value="<?php echo e($apartment->bed); ?>" placeholder="Enter bed">
                                                <?php $__errorArgs = ['bed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize">drawing</label>
                                                <input type="text" name="drawing" class="form-control text-capitalize"
                                                value="<?php echo e($apartment->drawing); ?>" placeholder="Enter drawing">
                                                <?php $__errorArgs = ['drawing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize">dining</label>
                                                <input type="text" name="dining" class="form-control text-capitalize"
                                                value="<?php echo e($apartment->dining); ?>" placeholder="Enter dining">
                                                <?php $__errorArgs = ['dining'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize">kitchen</label>
                                                <input type="text" name="kitchen" class="form-control text-capitalize"
                                                value="<?php echo e($apartment->kitchen); ?>" placeholder="Enter kitchen">
                                                <?php $__errorArgs = ['kitchen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize">washroom</label>
                                                <input type="text" name="washroom" class="form-control text-capitalize"
                                                value="<?php echo e($apartment->washroom); ?>" placeholder="Enter washroom">
                                                <?php $__errorArgs = ['washroom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label class="text-capitalize">Rent/Sell</label>
                                                <select name="select" class="form-control form-control-lg"
                                                    id="exampleFormControlSelect2">
                                                    <option selected disabled>select</option>
                                                    <option <?php echo e($apartment->rent_sell == 0? 'selected': ''); ?> value="0">Rent</option>
                                                    <option <?php echo e($apartment->rent_sell == 1? 'selected': ''); ?> value="1">Sell</option>
                                                </select>
                                                <?php $__errorArgs = ['select'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>


                                            <div class="col-md-12"><label
                                                    class="labels from-control text-capitalize mt-2">Description</label><textarea
                                                    name="text" class="form-control text-capitalize" id="" cols="50" 
                                                    rows="12"><?php echo e($apartment->text); ?></textarea>
                                                <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="form-text text-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>



                                        </div>
                                        <div class="mt-5 text-center"><button
                                                class="btn btn-primary profile-button  profile-button text-uppercase"
                                                type="submit"> <i class="far fa-check-square btn-icon-prepend"></i>
                                                Submit</button>
                                        </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>


        <script>

           // single image preview------------------

            document.getElementById("file-id-preview").style.visibility = "hidden";

            function showPreview(event) {
                if (event.target.files.length > 0) {
                    var src = URL.createObjectURL(event.target.files[0]);
                    var preview = document.getElementById("file-id-preview");
                    preview.src = src;
                    preview.style.display = "block";
                    document.getElementById("file-id-preview").style.visibility = "visible";
                }
            }

            // multiple image preview---------------------------

        $("#uploadFile").change(function(){        
           $('#multiple_image_preview').html("");        
           var total_file=document.getElementById("uploadFile").files.length;        
           for(var i=0;i<total_file;i++)        
           {   
            $('#multiple_image_preview').append("imgsrc='"+URL.createObjectURL(event.target.files[i])+"'>");        
           }
        
        });
              

        </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laravel\New folder\Apartment-Finding-System\Backend\resources\views/seller/apartment/edit_apartment.blade.php ENDPATH**/ ?>