

<?php $__env->startSection('main_content'); ?>
    <!-- partial -->
         


            <div class="container-fluid">
                <div class="content-wrapper">
                    <div class="page-header">
                        <h3 class="page-title">
                            <a class="btn btn-success btn-rounded" href="<?php echo e(route('seller.apartmentView')); ?>"><i class="fa fa-eye">
                                </i>&nbsp All Apartment</a>
        
                        </h3>
                      
                    </div>
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <div class="container rounded bg-white mb-3">
        
                                    <div class="row">
                                   
                                            <div class="col-md-12 border-right">
        
        
        
                                                <div class="row ">
        
        
                                                    <div class="col-md-6"><label class="labels text-capitalize">Feature
                                                            Picture</label><br>
                                                        <img id="" class="mt-1" width="210px"
                                                            src="<?php echo e(url('uploads/apartment_image/' . $apartment->image)); ?>" />
                                                    </div>
        
                                                    <div class="col-md-6"><label class="labels text-capitalize">Gallery
                                                            Picture</label><br>
                                                        <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                                                            <img class="mt-1" width="210px"
                                                                src="<?php echo e(url('uploads/galleries/' . $data->image_file)); ?>" />
        
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
                                                    </div>       
        
        
                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">Apartment Name</label>
                                                       
                                                    </div>
        
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->apartment_name); ?>

                                                          </h5>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">Apartment Address</label>                                                      
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->address); ?>

                                                          </h5>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">Contact</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->contact); ?>

                                                          </h5>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">Apartment size</label>                                                      
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->flat_size); ?>

                                                        </h5>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">City</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->city); ?>

                                                        </h5>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">rent/price</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->price); ?>

                                                        </h5>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">Bed</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->bed); ?>

                                                        </h5>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">drawing</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->drawing); ?>

                                                        </h5>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">dining</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->dining); ?>

                                                        </h5>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">kitchen</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->kitchen); ?>

                                                        </h5>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">washroom</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->washroom); ?>

                                                        </h5>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">rent/sell</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->rent_sell); ?>

                                                        </h5>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <label class="text-capitalize ">Description</label>                                                      
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <h5  class="text-capitalize">
                                                            <?php echo e($apartment->text); ?>

                                                        </h5>
                                                    </div>
                                                    
                                    </div>
                                </div>
        
                            </div>
                        </div>
                    </div>
                </div>
        
            </div>
        </div>
    </div>
            

        </div>
    </div>
    



            <?php $__env->stopSection(); ?>
<?php echo $__env->make('seller.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laravel\New folder\Apartment-Finding-System\Backend\resources\views/seller/apartment/apartmentdetails.blade.php ENDPATH**/ ?>